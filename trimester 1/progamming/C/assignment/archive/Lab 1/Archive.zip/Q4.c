#include <stdio.h>
int main(void)
{ //writing GNU is not UNIX in 2 line and in an astric box
printf("\n\n\n\n\n\n\n\n\n\n");
printf(" ************************\n");
printf(" * GNU is               *\n");
printf(" * not UNIX             *\n");
printf(" ************************\n");
printf("\n\n\n\n\n\n\n\n\n\n");
/*result:
 ************************
 * GNU is               *
 * not UNIX             *
 ************************
*/
return 0;
}