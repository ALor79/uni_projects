#include<stdio.h>
int main (){
    //writing the text Hello World
    printf(" Hello  World ");

    return 0;
}