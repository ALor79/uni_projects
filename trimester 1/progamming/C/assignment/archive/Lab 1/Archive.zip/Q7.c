#include<stdio.h>
int main (){
    //writing (G)NU is (N)ot (U)nix with a line break
  printf("one\n");
  printf("two\n");
  printf("three\n");
    
     
    return 0;
}