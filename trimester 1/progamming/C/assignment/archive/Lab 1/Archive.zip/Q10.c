#include <stdio.h>
int main(void)
{ //writing she sells sea shells by the seashore in a box with '='
printf("\n\n\n");
printf(" ========================================\n");
printf(" = she sells sea shells by the seashore =\n");
printf(" ========================================\n");
printf("\n\n\n");
/*result:
========================================
= she sells sea shells by the seashore =
========================================
*/
return 0;
}