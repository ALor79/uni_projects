#include<stdio.h>
int main (){
    //writing (G)NU is (N)ot (U)nix with a line break
  printf("o");
  printf("n");
  printf("e");
  printf(" ");
  printf("\n");
  printf("t");
  printf("w");
  printf("o");
  
    
     
    return 0;
}