#include<stdio.h>
int main (){
    //writing "(G)NU is" a line break and " (N)ot (U)nix" 
  printf("G)NU is \n(N)ot (U)nix ");
    /* result:
    G)NU is 
    (N)ot (U)nix
    */
     
    return 0;
}