#include<stdio.h>
int main (){
    //writing (G)NU is (N)ot (U)nix with a line break
  printf("one\ntwo\n");
    
     
    return 0;
}