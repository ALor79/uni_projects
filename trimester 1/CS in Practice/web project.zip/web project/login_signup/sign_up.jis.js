const pass = document.getElementById("pass");
const confirm = document.getElementById("confirm");
const submit = document.getElementById("submit")
function notRight(){
    if (pass!=confirm) {
        console.log("please retry")
        
    }
}
